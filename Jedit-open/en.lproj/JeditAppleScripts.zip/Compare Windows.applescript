--
-- Compare Windows.applescript
-- 最前面の2つの書類をカーソル位置から比較（厳密比較）
-- JXA(JavaScript)で高速・Unicode正確に比較
-- window id を使用して同名書類にも対応
--

tell application "Jedit"
	activate
	if (count of documents) < 2 then
		display dialog "比較するには2つ以上の書類を開いてください。" buttons {"OK"} default button "OK"
		return
	end if

	-- window id で一意に参照（同名書類対応）
	set wid1 to id of window 1
	set wid2 to id of window 2
	set name1 to name of document of window id wid1
	set name2 to name of document of window id wid2

	set theText1 to text of document of window id wid1 as string
	set theText2 to text of document of window id wid2 as string

	set loc1 to selection location of document of window id wid1
	set loc2 to selection location of document of window id wid2
	set len1 to count of theText1
	set len2 to count of theText2
end tell

-- カーソル位置から末尾までを取得
if loc1 ≥ len1 then
	set sub1 to ""
else if loc1 = 0 then
	set sub1 to theText1
else
	set sub1 to text (loc1 + 1) thru -1 of theText1
end if

if loc2 ≥ len2 then
	set sub2 to ""
else if loc2 = 0 then
	set sub2 to theText2
else
	set sub2 to text (loc2 + 1) thru -1 of theText2
end if

-- 一時ファイルに書き出し
set tmpDir to do shell script "mktemp -d /tmp/jedit_cmp_XXXXXX"
set f1 to tmpDir & "/t1.txt"
set f2 to tmpDir & "/t2.txt"
my writeUTF8(sub1, f1)
my writeUTF8(sub2, f2)

-- JXA(JavaScript)で比較（osascriptは全macOSに標準搭載）
set jsCode to "ObjC.import(\"Foundation\");" & ¬
	"var s1=ObjC.unwrap($.NSString.stringWithContentsOfFileEncodingError(\"" & f1 & "\",4,null));" & ¬
	"var s2=ObjC.unwrap($.NSString.stringWithContentsOfFileEncodingError(\"" & f2 & "\",4,null));" & ¬
	"var n=Math.min(s1.length,s2.length),p=-1;" & ¬
	"for(var i=0;i<n;i++){if(s1[i]!==s2[i]){p=i;break;}}" & ¬
	"(p<0)?((s1.length===s2.length)?\"MATCH\":\"\"+n):\"\"+p;"

try
	set cmpResult to do shell script "/usr/bin/osascript -l JavaScript -e " & quoted form of jsCode
on error errMsg
	do shell script "rm -rf " & quoted form of tmpDir
	tell application "Jedit"
		display dialog "エラー: " & errMsg buttons {"OK"} default button "OK" with icon caution
	end tell
	return
end try

do shell script "rm -rf " & quoted form of tmpDir

if cmpResult = "MATCH" then
	tell application "Jedit"
		display dialog name1 & " と " & name2 & " はカーソル位置以降同一です。" buttons {"OK"} default button "OK"
	end tell
	return
end if

set diffPos to cmpResult as integer

tell application "Jedit"
	set newPos2 to loc2 + diffPos
	if newPos2 < len2 then
		select in document of window id wid2 location newPos2 length 1
	else
		select in document of window id wid2 location len2 length 0
	end if

	set newPos1 to loc1 + diffPos
	if newPos1 < len1 then
		select in document of window id wid1 location newPos1 length 1
	else
		select in document of window id wid1 location len1 length 0
	end if
end tell

on writeUTF8(theText, filePath)
	set fRef to open for access (POSIX file filePath) with write permission
	set eof fRef to 0
	write theText to fRef as «class utf8»
	close access fRef
end writeUTF8
